package com.example.plaban.uploadtoserver;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;
import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import static android.os.StrictMode.*;


public class UploadToServer extends Activity {



    TextView messageText;
    Button uploadButton;
    int serverResponseCode = 0;
    ProgressDialog dialog = null;
    String upLoadServerUri = null;
    public long startTime;
    /**********
     * File Path
     *************/


    final String uploadFilePath = "/storage/emulated/0/";
    final String uploadFileName = "/Notes/Data.txt";
    private boolean reachable;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_to_server);

        uploadButton = (Button) findViewById(R.id.uploadButton);
        Button computeLocal = (Button) findViewById(R.id.button_local);
        messageText = (TextView) findViewById(R.id.messageText);
        final EditText num = (EditText) findViewById(R.id.editText);


        computeLocal.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                final String numValue = num.getText().toString();
               // messageText.append(numValue);
                int n = Integer.parseInt(numValue);


                List<Integer> factors = new ArrayList<Integer>();

                long startTime;
                long endTime;
                startTime = System.currentTimeMillis();
                for (int i = 2; i <= n; i++) {
                    while (n % i == 0) {
                        factors.add(i);
                        n /= i;
                    }
                }

                ;


                System.out.println("Primefactors of 2,147,483,647");
                messageText.append("\n Computation finished locally. The result is");

                for (int i = 0; i < factors.size(); i++) {
                    String str = factors.get(i).toString();
                    str.concat(str);
                    messageText.append("\n"+str);


                }
                endTime = System.currentTimeMillis();
                long time = endTime - startTime;
                System.out.println("Time is " + time);

                String strLong = Long.toString(time);
                messageText.append("\n Running time locally: " + strLong + " Mili sec");


                BroadcastReceiver batteryLevelReceiver = new BroadcastReceiver() {
                    public void onReceive(Context context, Intent intent) {
                        context.unregisterReceiver(this);
                        double rawlevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                        double scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                        double level = -1;
                        if (rawlevel >= 0 && scale > 0) {
                            level = (rawlevel * 100) / scale;
                        }
                        messageText.append("\n Battery Level Remaining: " + rawlevel + "%");
                    }
                };
                IntentFilter batteryLevelFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
                registerReceiver(batteryLevelReceiver, batteryLevelFilter);


            /*  for (Integer integer : factors) {
                  i=i++;
             //     System.out.println(integer);
                  String strI = integer.toString();
                  messageText.setText(strI);
                  String str2 = integer.toString();
                  messageText.setText(str2);
              }
*/


            }
        });


   //     messageText.setText("Uploading file path :- '/mnt/sdcard/" + uploadFileName + "'");

        /************* Php script path ****************/
        upLoadServerUri = "http://tech2go.in/cgi-bin/UploadToServer.php";

        uploadButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {








                String sFileName="Data.txt";
                final String sBody = num.getText().toString();


                try
                {
                    File root = new File(Environment.getExternalStorageDirectory(), "Notes");
                    if (!root.exists()) {
                        root.mkdirs();
                    }
                    File gpxfile = new File(root, sFileName);
                    FileWriter writer = new FileWriter(gpxfile);
                    writer.append(sBody);
                    writer.flush();
                    writer.close();
                    Toast.makeText(UploadToServer.this, "Saved", Toast.LENGTH_SHORT).show();
                }
                catch(IOException e)
                {
                    e.printStackTrace();
                    //   importError = e.getMessage();
                    //   iError();
                }






                dialog = ProgressDialog.show(UploadToServer.this, "", "Uploading file...", true);
                startTime = System.currentTimeMillis();


                new Thread(new Runnable() {
                    public void run() {
                        runOnUiThread(new Runnable() {
                            public void run() {
                                messageText.setText("Calculation started on cloud.....");
                            }
                        });

                        uploadFile(uploadFilePath + "" + uploadFileName);

                    }
                }).start();




            }
        });
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    private List<Integer> primeFactors(int number) {


        int n = number;
        List<Integer> factors = new ArrayList<Integer>();

        long startTime;
        long endTime;
        startTime = System.currentTimeMillis();
        for (int i = 2; i <= n; i++) {
            while (n % i == 0) {
                factors.add(i);
                n /= i;
            }
        }

        endTime = System.currentTimeMillis();
        long time = endTime - startTime;
        System.out.println("Running time is " + time +" Mili sec");
        return factors;

    }












    public int uploadFile(String sourceFileUri) {


        String fileName = sourceFileUri;

        HttpURLConnection conn = null;
        DataOutputStream dos = null;
        String lineEnd = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";
        int bytesRead, bytesAvailable, bufferSize;
        byte[] buffer;
        int maxBufferSize = 1 * 1024 * 1024;
        File sourceFile = new File(sourceFileUri);

        if (!sourceFile.isFile()) {

            dialog.dismiss();

            Log.e("uploadFile", "Source File not exist :"
                    + uploadFilePath + "" + uploadFileName);

            runOnUiThread(new Runnable() {
                public void run() {
                    messageText.setText("Source File not exist :"
                            + uploadFilePath + "" + uploadFileName);
                }
            });

            return 0;

        } else {
            try {

                // open a URL connection to the Servlet
                FileInputStream fileInputStream = new FileInputStream(sourceFile);
                URL url = new URL(upLoadServerUri);

                // Open a HTTP  connection to  the URL
                conn = (HttpURLConnection) url.openConnection();
                conn.setDoInput(true); // Allow Inputs
                conn.setDoOutput(true); // Allow Outputs
                conn.setUseCaches(false); // Don't use a Cached Copy
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Connection", "Keep-Alive");
                conn.setRequestProperty("ENCTYPE", "multipart/form-data");
                conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
                conn.setRequestProperty("uploaded_file", fileName);

                dos = new DataOutputStream(conn.getOutputStream());

                dos.writeBytes(twoHyphens + boundary + lineEnd);
                dos.writeBytes("Content-Disposition: form-data; name= uploaded_file  ; filename=" + fileName + lineEnd);

                dos.writeBytes(lineEnd);

                // create a buffer of  maximum size
                bytesAvailable = fileInputStream.available();

                bufferSize = Math.min(bytesAvailable, maxBufferSize);
                buffer = new byte[bufferSize];

                // read file and write it into form...
                bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                while (bytesRead > 0) {

                    dos.write(buffer, 0, bufferSize);
                    bytesAvailable = fileInputStream.available();
                    bufferSize = Math.min(bytesAvailable, maxBufferSize);
                    bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                }

                // send multipart form data necesssary after file data...
                dos.writeBytes(lineEnd);
                dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

                // Responses from the server (code and message)
                serverResponseCode = conn.getResponseCode();
                String serverResponseMessage = conn.getResponseMessage();

                Log.i("uploadFile", "HTTP Response is : "
                        + serverResponseMessage + ": " + serverResponseCode);

                if (serverResponseCode == 200) {



                    runOnUiThread(new Runnable() {
                        public void run() {

                            String msg = "File Upload Completed.\n\n See uploaded file here : \n\n"
                                    + " http://www.tech2go.in/uploads/"
                                    + uploadFileName;

                //            messageText.setText(msg);

                        getInfo();
                            Toast.makeText(UploadToServer.this, "File Upload Complete.",
                                    Toast.LENGTH_SHORT).show();

                            //  RetrieveFeedTask val= (RetrieveFeedTask) new RetrieveFeedTask().execute("http://tech2go.in/newfile.txt");



                        }
                    });






                }

                //close the streams //
                fileInputStream.close();
                dos.flush();
                dos.close();

            } catch (MalformedURLException ex) {

                dialog.dismiss();
                ex.printStackTrace();

                runOnUiThread(new Runnable() {
                    public void run() {
                        messageText.setText("MalformedURLException Exception : check script url.");
                        Toast.makeText(UploadToServer.this, "MalformedURLException",
                                Toast.LENGTH_SHORT).show();
                    }
                });

                Log.e("Upload file to server", "error: " + ex.getMessage(), ex);
            } catch (Exception e) {

                dialog.dismiss();
                e.printStackTrace();

                runOnUiThread(new Runnable() {
                    public void run() {
                        messageText.setText("Got Exception : see logcat ");
                        Toast.makeText(UploadToServer.this, "Got Exception : see logcat ",
                                Toast.LENGTH_SHORT).show();
                    }
                });
                Log.e("Upload error", "Exception : " + e.getMessage(), e);
            }
            dialog.dismiss();
            return serverResponseCode;

        } // End else block
    }





    public void getInfo () {

        new Thread() {
            @Override
            public void run() {
                String path = "http://tech2go.in/newfile.txt";
                URL u = null;
                try {
                    u = new URL(path);
                    HttpURLConnection c = (HttpURLConnection) u.openConnection();
                    c.setRequestMethod("GET");
                    c.connect();
                    InputStream in = c.getInputStream();
                    final ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    byte[] buffer = new byte[1024];
                    in.read(buffer); // Read from Buffer.
                    bo.write(buffer); // Write Into Buffer.

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            TextView text = (TextView) findViewById(R.id.messageText);
                            String result= "\nComputation finished on the cloud. The result is " +bo.toString();
                            text.append(result);


                            final long endTime = System.currentTimeMillis();
                            long time = endTime - startTime;
                            //      messageText.setText(msg);
                            Toast.makeText(UploadToServer.this, "Time:" + time,
                                    Toast.LENGTH_SHORT).show();

                            messageText.append("\n Running time on cloud: " + time +" Mili sec");
                            try {
                                bo.close();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (ProtocolException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
            //   TextView.setText(total);
            // Toast.makeText(UploadToServer.this, "String:",
            //          Toast.LENGTH_SHORT).show();
        }.start();


    }






    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "UploadToServer Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://com.example.plaban.uploadtoserver/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }


















    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "UploadToServer Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app deep link URI is correct.
                Uri.parse("android-app://com.example.plaban.uploadtoserver/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    }
}